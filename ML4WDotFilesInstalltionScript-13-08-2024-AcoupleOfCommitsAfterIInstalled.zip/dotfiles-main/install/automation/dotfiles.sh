# ------------------------------------------------------
# Define dotfiles folder
# ------------------------------------------------------

echo -e "${GREEN}"
figlet "Folder"
echo -e "${NONE}"
dot_folder=$automation_dotfilesfolder
echo "AUTOMATION: Installation folder set to ~/$automation_dotfilesfolder"
echo