#!/bin/bash
echo $(cat ~/.config/ml4w/version/name) $(cat ~/.config/ml4w/version/version)
