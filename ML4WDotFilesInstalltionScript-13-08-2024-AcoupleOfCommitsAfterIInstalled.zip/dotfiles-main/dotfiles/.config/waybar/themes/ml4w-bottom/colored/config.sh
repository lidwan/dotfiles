#!/bin/bash
theme_name="ML4W Colored Bottom"