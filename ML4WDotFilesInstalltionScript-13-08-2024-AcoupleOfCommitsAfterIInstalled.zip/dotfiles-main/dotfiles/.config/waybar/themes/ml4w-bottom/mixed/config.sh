#!/bin/bash
theme_name="ML4W Mixed Bottom"