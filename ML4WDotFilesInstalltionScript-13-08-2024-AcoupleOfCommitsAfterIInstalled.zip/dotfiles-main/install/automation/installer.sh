# ------------------------------------------------------
# Installation method
# ------------------------------------------------------

echo ":: AUTOMATION: New packages will be installed"
force_install=0
echo