# ------------------------------------------------------
# Keyboard
# ------------------------------------------------------

echo -e "${GREEN}"
figlet "Keyboard"
echo -e "${NONE}"
echo ":: AUTOMATION: Proceed with existing keyboard configuration."
echo