# ------------------------------------------------------
# Display Manager
# ------------------------------------------------------

echo -e "${GREEN}"
figlet "Display Manager"
echo -e "${NONE}"
echo ":: AUTOMATION: Keep current setup of Display Manager"
disman=0
echo