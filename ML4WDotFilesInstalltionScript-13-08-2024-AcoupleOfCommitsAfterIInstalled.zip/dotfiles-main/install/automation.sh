# ------------------------------------------------------
# Check for automation.sh
# ------------------------------------------------------

if [ -f ~/dotfiles-versions/automation.sh ] ;then
    echo ":: AUTOMATION: automation.sh found"
    source ~/dotfiles-versions/automation.sh
    echo
fi